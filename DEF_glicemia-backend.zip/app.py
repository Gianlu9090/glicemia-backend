from flask import Flask, request, render_template, jsonify
import boto3
from cryptography.fernet import Fernet
import os
import logging

# Configurazione del logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

app = Flask(__name__)

# Legge la chiave segreta dalla variabile d'ambiente FERNET_KEY
fernet_key = os.environ.get("FERNET_KEY")
if not fernet_key:
    logger.warning("FERNET_KEY non trovata nelle variabili d'ambiente. Usando una chiave di default per lo sviluppo.")
    fernet_key = "8Qa-bJPN19jVFvKQppzi50_bMTvUXfASFmI8z5IaaU8="

f = Fernet(fernet_key.encode())

# Connessione a DynamoDB nella regione corretta
dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
DEXCOM_TABLE = dynamodb.Table("DexcomUsers")

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/submit", methods=["POST"])
def submit():
    try:
        user_id = request.form["userId"]
        username = request.form["username"]
        password = request.form["password"]
        consent = "consent" in request.form
        
        logger.info(f"Ricevuta richiesta di registrazione per userId: {user_id}")

        # Cifratura delle credenziali
        username_enc = f.encrypt(username.encode()).decode()
        password_enc = f.encrypt(password.encode()).decode()

        # Salvataggio su DynamoDB
        DEXCOM_TABLE.put_item(Item={
            "userId": user_id,
            "username": username_enc,
            "password": password_enc,
            "consent": consent
        })
        
        logger.info(f"Dati salvati con successo per userId: {user_id}")
        return f"Dati salvati con successo per l'utente {user_id}. Ora puoi utilizzare la skill Alexa."
    
    except Exception as e:
        logger.error(f"Errore durante il salvataggio dei dati: {e}")
        return f"Errore durante il salvataggio dei dati: {e}", 500

@app.route("/get_user", methods=["GET"])
def get_user():
    try:
        user_id = request.args.get("userId")
        if not user_id:
            logger.warning("Richiesta /get_user senza userId")
            return jsonify({"error": "userId non specificato"}), 400
        
        logger.info(f"Ricevuta richiesta /get_user per userId: {user_id}")
        
        # Recupera l'utente da DynamoDB
        response = DEXCOM_TABLE.get_item(Key={"userId": user_id})
        
        if "Item" not in response:
            logger.warning(f"Utente non trovato: {user_id}")
            return jsonify({"error": "Utente non trovato"}), 404
        
        user_data = response["Item"]
        
        # Decifra le credenziali
        username_dec = f.decrypt(user_data["username"].encode()).decode()
        password_dec = f.decrypt(user_data["password"].encode()).decode()
        
        logger.info(f"Dati utente recuperati con successo per userId: {user_id}")
        
        return jsonify({
            "username": username_dec,
            "password": password_dec
        })
    
    except Exception as e:
        logger.error(f"Errore durante il recupero dei dati: {e}")
        return jsonify({"error": str(e)}), 500

# Endpoint per verificare lo stato del servizio
@app.route("/health")
def health():
    return jsonify({"status": "ok"})

# Avvio del server Flask per Render (porta e host obbligatori)
if __name__ == "__main__":
    port = int(os.environ.get("PORT", 10000))
    app.run(host="0.0.0.0", port=port)
